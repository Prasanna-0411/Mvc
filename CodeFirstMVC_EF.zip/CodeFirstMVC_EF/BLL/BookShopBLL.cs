﻿using BLL.Interfaces;
using DAL.Interfaces;
using Models;

namespace BLL
{
    public class BookShopBLL : IBookshopBLL
    {
        private readonly IBookShopDAL _bookShopDAL;

        public BookShopBLL(IBookShopDAL bookShopDAL)
        {
            _bookShopDAL = bookShopDAL;
        }
        public List<BookShop> GetAllDetails()
        {
            var result = _bookShopDAL.GetAllDetails();
            return result;
        }

        public BookShop GetDetailsById(int id)
        {
            var result = _bookShopDAL.GetDetailsById(id);
            return result;
        }
        public int AddDetails(BookShop bookShop)
        {
            _bookShopDAL.AddDetails(bookShop);
            return bookShop.BookId;
        }

        public int UpdateDetails(BookShop bookShop)
        {
            _bookShopDAL.UpdateDetails(bookShop);
            return bookShop.BookId;
        }
        public int DeleteDetails(int id)   
        {
            _bookShopDAL.DeleteDetails(id);
            return id;
        }
    }
}
