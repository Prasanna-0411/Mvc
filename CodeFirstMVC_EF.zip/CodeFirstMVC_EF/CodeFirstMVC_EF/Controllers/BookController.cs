﻿using BLL.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Models;

namespace CodeFirstMVC_EF.Controllers
{
    public class BookController : Controller
    {
        private readonly IBookshopBLL _bookshopBLL;

        public BookController(IBookshopBLL bookshopBLL)
        {
            _bookshopBLL = bookshopBLL;
        }
        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.Header = "Hello";
            var result = _bookshopBLL.GetAllDetails();
            return View(result);
        }

        //Get method For Details
        [HttpGet]
        public IActionResult Details(int id)
        {
            if (id == 0)
            {
                return NotFound();
            }
            var books = _bookshopBLL.GetDetailsById(id);
            return View(books);
        }
        //Get method For Add Books
        [HttpGet]
        public IActionResult Create()
        {

            return View();
        }
        //Post method for Add Books
        
        [HttpPost]
        public ActionResult CreateBook(BookShop bookShop)
        {
            if (bookShop == null)
            {
                return BadRequest("Not found");
            }
            else
            {
                _bookshopBLL.AddDetails(bookShop);
            }
            return RedirectToAction("Index");
        }
        //Get method For Edit Books
        [HttpGet]
        public IActionResult Edit(int Id)
         {
            var result = _bookshopBLL.GetDetailsById(Id);
            return View(result);
        }
        //Post method for Edit Books

        [HttpPost]
        public ActionResult EditBook(BookShop bookShop)
        {
            if (bookShop == null)
            {
                return BadRequest("Not found");
            }
            else
            {
                _bookshopBLL.UpdateDetails(bookShop);
            }
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Delete(int Id)
        {
            var result = _bookshopBLL.GetDetailsById(Id);
            return View(result);
        }


        [HttpPost]
        public ActionResult DeleteBook(int id)
        {
            if (id == null)
            {
                return BadRequest("Not found");
            }
            else
            {
                _bookshopBLL.DeleteDetails(id);
            }
            return RedirectToAction("Index");
        }

    }
}

