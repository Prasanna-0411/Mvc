﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations;

namespace Models
{
    public class BookShop
    {
        [Key]
        public int BookId { get; set; }
        public string BookName { get; set; }
        public string? AuthorName { get; set; }
        public float price { get; set; }
    }
}
