﻿using DAL.Interfaces;
using Models;
using Models.Context;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace DAL
{
    public class BookShopDAL : IBookShopDAL
    {
        private readonly BookShopContext _bookShopContext;

        public BookShopDAL(BookShopContext bookShopContext)
        {
            _bookShopContext = bookShopContext;
        }

        public List<BookShop> GetAllDetails()
        {
           var result = _bookShopContext.Books.ToList();
            return result;
        }

        public BookShop GetDetailsById(int id)
        {
            var result = _bookShopContext.Books.FirstOrDefault(bk => bk.BookId == id);
            return result;
        }
        public int AddDetails(BookShop bookShop)
        {
            var result = _bookShopContext.Add(bookShop);
            _bookShopContext.SaveChanges();
            return bookShop.BookId;
        }

        public int UpdateDetails(BookShop bookShop)
        {
           // var update = _bookShopContext.Books.Where(bk =>bk.BookId == bookShop.BookId).ToList();
            var result = _bookShopContext.Update(bookShop);
            _bookShopContext.SaveChanges();
            return bookShop.BookId;
            
        } 


        public int DeleteDetails(int id)
        {
            var value = _bookShopContext.Books.Find(id);
            var result = _bookShopContext.Remove(value);
            return value.BookId;
        }
    }
}
